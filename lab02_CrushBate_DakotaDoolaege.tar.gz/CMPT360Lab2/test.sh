./xxsh << HERE
env
export HISTSIZE=10
env
export user=tux
export random=rand
history
env
1
2
3
4
5
history
export
export HISTSIZE=2
history
exit
HERE
